$(document).ready(function(){

	SyntaxHighlighter.defaults['toolbar'] = false;
	SyntaxHighlighter.all();
});
